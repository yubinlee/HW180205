
public class CategoryVO {

}
